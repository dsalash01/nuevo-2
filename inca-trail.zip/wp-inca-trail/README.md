# README #

Inca Trail Plugin para wordpress

### What is this repository for? ###

* Complatible con la version de wordpress 4
* Tiempo real de los datos